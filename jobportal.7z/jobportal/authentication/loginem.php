<?php
session_start();
include_once('../databaseclass/dbconnect.php');
include_once('../class/class.globalfunction.php');
extract($_POST);


print_r($_POST);
$obj=new authentication();
$result=$obj->check_authen_employer("employer");
$result->execute();
print_r($result);

foreach ($result as $data)
	{
		//extracted from database employer
		$usname=$data['eusername'];
		$uspass=$data['password'];
		//from form submit
		$eusername=$_POST['eusername'];
		$password=($_POST['password']);
		echo 'username:'.$eusername. '<br>';
		echo 'password:'.$password. '<br>';
		echo 'usname:'.$usname. '<br>';
		echo 'uspass:'.$uspass. '<br>';
		
		if($eusername==$usname && $password==$uspass)
		{
			
			//echo "successful";
			$flag=1;
			//$js_id=$data['js_id'];
			break;	
		}
		else
		{
			header('location:../Employer/employerLoginForm.php?msg=Unsuccessfull....');
			//echo "unsuccessful";
			//break;
		}	
	}
		
		if($flag==1)	
			{
			
				$_SESSION['eusername']=$eusername;
				header('location:../Employer/dashboardEmp.php?msg=Successfull');
			
			
			}
			
	
?>


