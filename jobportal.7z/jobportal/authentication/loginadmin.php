<?php
session_start();
include_once('../databaseclass/dbconnect.php');
include_once('../class/class.globalfunction.php');
extract($_POST);


print_r($_POST);
$obj=new authentication();
$result=$obj->check_authen_admin("admin");
$result->execute();
print_r($result);

foreach ($result as $data)
	{
		//extracted from database admin
		$usname=$data['username'];
		$uspass=$data['password'];
		//from form submit
		$username=$_POST['username'];
		$password=($_POST['password']);
		echo 'username:'.$username. '<br>';
		echo 'password:'.$password. '<br>';
		echo 'usname:'.$usname. '<br>';
		echo 'uspass:'.$uspass. '<br>';
		
		if($username==$usname && $password==$uspass)
		{
			
			//echo "successful";
			$flag=1;
			//$js_id=$data['js_id'];
			break;	
		}
		else
		{
			header('location:../admin/adminLoginForm.php?msg=unsuccessfull....');
			//echo "unsuccessful";
			//break;
		}	
	}
		
		if($flag==1)	
			{
			
				$_SESSION['username']=$username;
				header('location:../admin/dashboard_admin.php?msg=successfull');
			
			
			}
			
			
	
?>


